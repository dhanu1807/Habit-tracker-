Habit Tracker - deployable web app

1. Upload this whole folder to any static host (Netlify Drop, GitHub Pages, Cloudflare Pages, Vercel).
2. Open the https link on a phone.
3. Android/Chrome: menu > Install app. iPhone/Safari: Share > Add to Home Screen.

It works offline after the first visit. Data stays on each user's device.
